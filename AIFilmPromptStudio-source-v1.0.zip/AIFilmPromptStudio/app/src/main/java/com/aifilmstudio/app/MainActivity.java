package com.aifilmstudio.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 42;
    private final int ink = Color.rgb(30, 38, 56);
    private final int muted = Color.rgb(103, 113, 132);
    private final int blue = Color.rgb(59, 110, 234);
    private final int bg = Color.rgb(247, 248, 252);
    private SharedPreferences prefs;
    private JSONArray scenes;
    private String projectName = "Proyek Film Saya";
    private String revisionMode = "Hybrid";
    private LinearLayout root;
    private String activePage = "Beranda";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("film_studio", MODE_PRIVATE);
        loadData();
        render("Beranda");
    }

    private void loadData() {
        projectName = prefs.getString("project_name", "Proyek Film Saya");
        revisionMode = prefs.getString("revision_mode", "Hybrid");
        try { scenes = new JSONArray(prefs.getString("scenes", "[]")); }
        catch (Exception e) { scenes = new JSONArray(); }
    }
    private void saveData() {
        prefs.edit().putString("project_name", projectName).putString("revision_mode", revisionMode).putString("scenes", scenes.toString()).apply();
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int all) { v.setPadding(dp(all), dp(all), dp(all), dp(all)); }
    private Button button(String label, Runnable action, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(primary ? Color.WHITE : ink);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? blue : Color.rgb(232,236,245)));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void card(LinearLayout parent, View child) {
        LinearLayout c = column(); c.setBackgroundColor(Color.WHITE); c.setElevation(dp(1)); pad(c, 14);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(12); parent.addView(c,p); c.addView(child);
    }
    private void render(String page) {
        activePage = page;
        root = column(); root.setBackgroundColor(bg);
        LinearLayout header = column(); header.setPadding(dp(20), dp(18), dp(20), dp(12));
        header.addView(text("AI FILM PROMPT STUDIO", 12, true, blue));
        header.addView(text(page, 26, true, ink));
        root.addView(header);
        ScrollView scroll = new ScrollView(this); LinearLayout content = column(); content.setPadding(dp(16), dp(4), dp(16), dp(16)); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        if (page.equals("Beranda")) home(content);
        else if (page.equals("Proyek")) project(content);
        else if (page.equals("Scene")) scenePage(content);
        else if (page.equals("Prompt")) promptPage(content);
        else if (page.equals("Ekspor")) exportPage(content);
        LinearLayout nav = row(); nav.setBackgroundColor(Color.WHITE); nav.setPadding(dp(4),dp(4),dp(4),dp(4));
        String[] pages = {"Beranda","Proyek","Scene","Prompt","Ekspor"};
        for (String item : pages) { Button b = new Button(this); b.setText(item); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(item.equals(page)?blue:muted); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(v -> render(item)); nav.addView(b,new LinearLayout.LayoutParams(0,dp(52),1)); }
        root.addView(nav); setContentView(root);
    }
    private void home(LinearLayout c) {
        LinearLayout intro = column(); intro.addView(text("Ruang kerja film lo",22,true,ink)); intro.addView(text("Susun cerita per scene, jaga konsistensi, lalu buat prompt produksi.",14,false,muted)); card(c,intro);
        LinearLayout stat = column(); stat.addView(text("PROYEK AKTIF",11,true,muted)); stat.addView(text(projectName,20,true,ink)); stat.addView(text(scenes.length()+" scene tersimpan",14,false,muted)); card(c,stat);
        card(c,button("+ Tambah scene", this::addSceneDialog, true));
        card(c,button("Atur proyek", () -> render("Proyek"), false));
        card(c,button("Buat prompt", () -> render("Prompt"), false));
        TextView note = text("Tips: isi cerita dan kondisi akhir scene supaya kontinuitas scene berikutnya lebih mudah diperiksa.",13,false,muted); card(c,note);
    }
    private void project(LinearLayout c) {
        LinearLayout box = column(); box.addView(text("Nama proyek",14,true,ink)); EditText name = new EditText(this); name.setSingleLine(true); name.setText(projectName); name.setHint("Nama proyek"); box.addView(name);
        box.addView(text("Mode revisi scene",14,true,ink)); Spinner mode = new Spinner(this); String[] modes={"Hybrid","Otomatis","Manual"}; mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes)); mode.setSelection(java.util.Arrays.asList(modes).indexOf(revisionMode)); box.addView(mode);
        box.addView(button("Simpan pengaturan", () -> { projectName=name.getText().toString().trim(); if(projectName.isEmpty()) projectName="Proyek Film Saya"; revisionMode=String.valueOf(mode.getSelectedItem()); saveData(); Toast.makeText(this,"Pengaturan tersimpan",Toast.LENGTH_SHORT).show(); render("Proyek"); }, true)); card(c,box);
        TextView explain=text("Mode revisi menentukan cara kerja revisi yang disarankan. Versi awal ini menyimpan pengaturan lokal; revisi AI otomatis belum terhubung ke model AI.",13,false,muted); card(c,explain);
    }
    private void addSceneDialog() {
        LinearLayout form=column(); EditText title=new EditText(this); title.setHint("Judul scene"); form.addView(title); EditText story=new EditText(this); story.setHint("Apa yang terjadi?"); story.setMinLines(3); story.setGravity(Gravity.TOP); form.addView(story); EditText start=new EditText(this); start.setHint("Kondisi awal"); form.addView(start); EditText end=new EditText(this); end.setHint("Kondisi akhir"); form.addView(end); EditText poi=new EditText(this); poi.setHint("POI / fokus utama"); form.addView(poi);
        new AlertDialog.Builder(this).setTitle("Tambah scene").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try { JSONObject s=new JSONObject(); s.put("id","SC_"+String.format(java.util.Locale.US,"%03d",scenes.length()+1)); s.put("title",title.getText().toString().trim().isEmpty()?"Scene "+(scenes.length()+1):title.getText().toString().trim()); s.put("story",story.getText().toString()); s.put("start",start.getText().toString()); s.put("end",end.getText().toString()); s.put("poi",poi.getText().toString()); scenes.put(s); saveData(); render("Scene"); Toast.makeText(this,"Scene tersimpan",Toast.LENGTH_SHORT).show(); } catch(Exception e){Toast.makeText(this,"Scene gagal disimpan",Toast.LENGTH_SHORT).show();}
        }).show();
    }
    private void scenePage(LinearLayout c) {
        card(c,button("+ Tambah scene",this::addSceneDialog,true));
        if(scenes.length()==0){ card(c,text("Belum ada scene. Tambahkan scene pertama untuk mulai menyusun cerita.",14,false,muted)); return; }
        for(int i=0;i<scenes.length();i++){ final int index=i; try { JSONObject s=scenes.getJSONObject(i); LinearLayout b=column(); b.addView(text(s.optString("id")+"  ·  "+s.optString("title"),17,true,ink)); b.addView(text(s.optString("story","(cerita belum diisi)"),14,false,muted)); LinearLayout actions=row(); actions.addView(button("Edit",()->editScene(index),false),new LinearLayout.LayoutParams(0,-2,1)); actions.addView(button("Hapus",()->deleteScene(index),false),new LinearLayout.LayoutParams(0,-2,1)); b.addView(actions); card(c,b); }catch(Exception ignored){} }
    }
    private void editScene(int index) {
        try { JSONObject s=scenes.getJSONObject(index); LinearLayout form=column(); EditText title=new EditText(this); title.setText(s.optString("title")); title.setHint("Judul"); form.addView(title); EditText story=new EditText(this); story.setText(s.optString("story")); story.setHint("Apa yang terjadi?"); story.setMinLines(3); story.setGravity(Gravity.TOP); form.addView(story); EditText start=new EditText(this); start.setText(s.optString("start")); start.setHint("Kondisi awal"); form.addView(start); EditText end=new EditText(this); end.setText(s.optString("end")); end.setHint("Kondisi akhir"); form.addView(end); EditText poi=new EditText(this); poi.setText(s.optString("poi")); poi.setHint("POI"); form.addView(poi);
        new AlertDialog.Builder(this).setTitle("Edit scene").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{s.put("title",title.getText().toString());s.put("story",story.getText().toString());s.put("start",start.getText().toString());s.put("end",end.getText().toString());s.put("poi",poi.getText().toString());scenes.put(index,s);saveData();render("Scene");}catch(Exception e){Toast.makeText(this,"Gagal menyimpan",Toast.LENGTH_SHORT).show();}}).show(); } catch(Exception ignored){}
    }
    private void deleteScene(int index) { new AlertDialog.Builder(this).setTitle("Hapus scene?").setMessage("Scene ini akan dihapus dari proyek lokal.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{JSONArray next=new JSONArray();for(int i=0;i<scenes.length();i++)if(i!=index)next.put(scenes.opt(i));scenes=next;saveData();render("Scene");}).show(); }
    private String buildPrompt() {
        StringBuilder out=new StringBuilder(); out.append("PROYEK: ").append(projectName).append("\nMODE REVISI: ").append(revisionMode).append("\n\n");
        if(scenes.length()==0)return out.append("Belum ada scene. Tambahkan cerita terlebih dahulu.").toString();
        for(int i=0;i<scenes.length();i++){JSONObject s=scenes.optJSONObject(i);if(s==null)continue;out.append("SCENE ").append(i+1).append(" — ").append(s.optString("title")).append("\n");out.append("Cerita/aksi: ").append(blank(s.optString("story"))).append("\nKondisi awal: ").append(blank(s.optString("start"))).append("\nKondisi akhir: ").append(blank(s.optString("end"))).append("\nPOI: ").append(blank(s.optString("poi"))).append("\n\nPROMPT IMAGE:\nCinematic composition of the scene described above. Preserve established character, location, prop, and color references when supplied. Keep the point of interest clear. Do not invent missing canonical details.\n\nPROMPT MOTION:\nAnimate the described action with coherent movement and continuity from the stated starting state to ending state. Preserve identity, props, and point of interest. Do not invent unsupported details.\n\n---\n\n");}
        return out.toString();
    }
    private String blank(String s){return s==null||s.trim().isEmpty()?"Belum ditentukan":s;}
    private void promptPage(LinearLayout c) {
        card(c,text("Prompt dihasilkan dari data scene yang tersimpan. Karena belum terhubung ke model AI, ini adalah draf templat, bukan hasil generasi AI atau validasi visual.",13,false,muted));
        EditText output=new EditText(this); output.setText(buildPrompt()); output.setTextSize(13); output.setGravity(Gravity.TOP); output.setMinLines(12); output.setPadding(dp(12),dp(12),dp(12),dp(12)); output.setBackgroundColor(Color.WHITE); c.addView(output,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout buttons=row(); buttons.addView(button("Salin",()->{ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cb.setPrimaryClip(ClipData.newPlainText("Prompt",output.getText().toString()));Toast.makeText(this,"Prompt disalin",Toast.LENGTH_SHORT).show();},true),new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(button("Perbarui",()->render("Prompt"),false),new LinearLayout.LayoutParams(0,-2,1)); c.addView(buttons);
    }
    private void exportPage(LinearLayout c) {
        card(c,text("Ekspor prompt",18,true,ink)); card(c,button("Ekspor prompt sebagai TXT",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"AI_Film_Prompt.txt");startActivityForResult(i,CREATE_FILE);},true));
        card(c,button("Salin semua prompt",()->{ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cb.setPrimaryClip(ClipData.newPlainText("Prompt",buildPrompt()));Toast.makeText(this,"Prompt disalin",Toast.LENGTH_SHORT).show();},false));
        card(c,text("Backup proyek ZIP belum diimplementasikan pada prototipe ini. Data proyek saat ini disimpan lokal di perangkat. Jangan menganggap data sudah dicadangkan sampai fitur backup diuji.",13,false,muted));
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==CREATE_FILE&&resultCode==RESULT_OK&&data!=null){Uri uri=data.getData();try(java.io.OutputStream os=getContentResolver().openOutputStream(uri)){if(os!=null){os.write(buildPrompt().getBytes(java.nio.charset.StandardCharsets.UTF_8));os.flush();Toast.makeText(this,"Prompt berhasil diekspor",Toast.LENGTH_LONG).show();}}catch(Exception e){Toast.makeText(this,"Ekspor gagal. Coba lokasi lain.",Toast.LENGTH_LONG).show();}}}
}
