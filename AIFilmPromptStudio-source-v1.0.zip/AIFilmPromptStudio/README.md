# AI Film Prompt Studio — Android starter project

This is the first runnable-source prototype for the agreed v1.0 scope. It uses native Android Java views and local SharedPreferences; it has no external dependencies beyond the Android Gradle Plugin.

## Included in this prototype
- Home screen and simple bottom navigation
- Local project name and revision-mode settings (Automatic / Manual / Hybrid)
- Add, edit, and delete scene records
- Scene fields: story/action, starting state, ending state, POI
- Template-based image and motion prompt draft
- Copy prompt to clipboard and export prompt as TXT using Android's document picker
- Local persistence across app restarts

## Not yet implemented
- Actual AI/model connection or automatic AI revisions
- Character/location/prop reference registry and reference file management
- Continuity QC engine and approval/version snapshots
- ZIP project backup/restore
- Visual-output testing against a real generator

Prompt text is a template draft, not AI-generated or visually validated output. This project source has not been compiled into an APK in this environment.

## Build
Open the project in Android Studio with Android SDK 35 installed, sync Gradle, then Build > Build APK(s). The project uses Android Gradle Plugin 8.7.3 and Java.
